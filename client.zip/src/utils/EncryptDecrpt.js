class CryptoService {
    // Generate ECDH Key Pair (using P-256 curve)
    async generateECDHKeys() {
      const keys = await crypto.subtle.generateKey(
        {
          name: "ECDH",
          namedCurve: "P-256",
        },
        true,
        ["deriveKey", "deriveBits"]
      );
      return keys;
    }
  
    // Derive shared secret using ECDH
    async deriveSharedSecret(privateKey, publicKey) {
      const sharedSecret = await crypto.subtle.deriveBits(
        {
          name: "ECDH",
          public: publicKey,
        },
        privateKey,
        256 // Length in bits
      );
      return sharedSecret; // Raw shared secret for AES key derivation
    }
  
    // Derive AES key from shared secret
    async deriveAESKey(sharedSecret) {
      const aesKey = await crypto.subtle.importKey(
        "raw",
        sharedSecret,
        { name: "AES-GCM" },
        false,
        ["encrypt", "decrypt"]
      );
      return aesKey;
    }
  
    // AES GCM Encryption
    async encryptData(aesKey, data) {
      const encoder = new TextEncoder();
      const iv = crypto.getRandomValues(new Uint8Array(12)); // 12 bytes IV
      const encodedData = encoder.encode(data);
  
      const encryptedData = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv },
        aesKey,
        encodedData
      );
  
      const resultArray = new Uint8Array(iv.length + encryptedData.byteLength);
      resultArray.set(iv);
      resultArray.set(new Uint8Array(encryptedData), iv.length);
  
      return btoa(String.fromCharCode(...resultArray)); // Base64 encode
    }
  
    // AES GCM Decryption
    async decryptData(aesKey, encryptedData) {
      const encryptedArray = new Uint8Array(
        atob(encryptedData)
          .split("")
          .map((char) => char.charCodeAt(0))
      );
  
      const iv = encryptedArray.slice(0, 12);
      const ciphertext = encryptedArray.slice(12);
  
      const decryptedData = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: iv },
        aesKey,
        ciphertext
      );
  
      return new TextDecoder().decode(decryptedData);
    }
  }
  
  // Exporting instance for use in React components
  const cryptoService = new CryptoService();
  export default cryptoService;
  