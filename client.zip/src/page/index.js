import React, { useState } from 'react';
import Axios from 'axios';

function App() {
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('');

  
  // Generate ECDH key pair on the frontend (client)
  async function generateECDHKeyPair() {
    const algorithm = { name: 'ECDH', namedCurve: 'P-256' }; // Using P-256 for ECDH
    const keyPair = await window.crypto.subtle.generateKey(
      algorithm,
      true,
      ['deriveKey', 'deriveBits']
    );
    return keyPair;
  }

  // Derive shared secret using the client's private key and the server's public key
  async function deriveSharedSecret(clientPrivateKey, serverPublicKey) {
    const sharedSecret = await window.crypto.subtle.deriveBits(
      {
        name: 'ECDH',
        public: serverPublicKey,
      },
      clientPrivateKey,
      256 // Length of the shared secret (in bits)
    );
    return sharedSecret;
  }

  // Convert the derived secret to a symmetric key for AES encryption
  async function deriveSymmetricKey(sharedSecret) {
    const keyMaterial = await window.crypto.subtle.importKey(
      'raw',
      sharedSecret,
      'AES-GCM',
      true,
      ['encrypt', 'decrypt']
    );
    return keyMaterial;
  }

  // AES-GCM encryption
  async function encryptText(plainText, symmetricKey) {
    const iv = window.crypto.getRandomValues(new Uint8Array(12)); // Initialization Vector for AES/GCM
    const encoder = new TextEncoder();
    const data = encoder.encode(plainText);

    const encryptedData = await window.crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv,
      },
      symmetricKey,
      data
    );

    return {
      iv: iv,
      encryptedText: new Uint8Array(encryptedData),
    };
  }

  // Click handler
  const handleEncrypt = async () => {
    console.log('asdasd');
    setStatus('Processing...');

    try {
      const clientKeyPair = await generateECDHKeyPair();

      // Assuming we have the server's public key (this could be fetched from your backend)
      const serverPublicKey = await fetchServerPublicKey(); // function to fetch the server's public key
  
      const sharedSecret = await deriveSharedSecret(
        clientKeyPair.privateKey,
        serverPublicKey
      );

      const symmetricKey = await deriveSymmetricKey(sharedSecret);
      console.log('asfgg',symmetricKey);
      const { iv, encryptedText } = await encryptText('Sensitive Data', symmetricKey);

      // Send the encrypted text and IV to the backend
      const response = await Axios.post('http://localhost:3001/api/encrypt', {
        method: 'POST',
        body: JSON.stringify({
          iv: Array.from(iv),
          encryptedText: Array.from(encryptedText),
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const responseData = await response.json();
      setMessage(responseData.message);
      setStatus('Encryption complete.');
    } catch (error) {
      console.error('Error during encryption:', error);
      setStatus('Error occurred during encryption.');
    }
  };

  // Mock function to simulate fetching the server's public key
  const fetchServerPublicKeyOld = async () => {
    // Replace this with an actual API call to your backend
    const publicKey = await fetch('http://localhost:3001/api/public-key');
    const publicKeyData = await publicKey.json();
    return window.crypto.subtle.importKey(
      'jwk',
      publicKeyData, // Public key data in JWK format
      { name: 'ECDH', namedCurve: 'P-256' },
      false,
      ['deriveBits']
    );
  };

  // Fetch the public key from the server
const fetchServerPublicKey2 = async () => {
    const publicKeyResponse = await fetch('http://localhost:3001/api/public-key');
    const publicKeyData = await publicKeyResponse.json();
  
    // Import the public key in JWK format
    const serverPublicKey1 = await window.crypto.subtle.importKey(
      'jwk', // The key format is 'jwk'
      publicKeyData, // The public key object we received from the server
      { name: 'ECDH', namedCurve: 'P-256' }, // The algorithm used for ECDH
      false, // The key is not extractable
      ['deriveBits'] // The key is used for deriving shared secrets
    );
    return serverPublicKey1;
  };
  
// Fetch the public key from the server
const fetchServerPublicKey = async () => {
    const publicKeyResponse = await Axios.get('http://localhost:3001/api/public-key');
    const publicKeyData = await publicKeyResponse.json();
    console.log('asdsf',publicKeyData)
    // Import the server's public key in JWK format for ECDH
    const serverPublicKey = await window.crypto.subtle.importKey(
      'jwk', // Importing as JWK (JSON Web Key)
      publicKeyData, // The public key object we received from the server
      { name: 'ECDH', namedCurve: 'P-256' }, // ECDH algorithm with P-256 curve
      false, // The key is not extractable
      ['deriveBits'] // We will use this key for key exchange (deriving shared secrets)
    );
    return serverPublicKey;
  };
  
  
  return (
    <div>
      <button onClick={handleEncrypt}>Encrypt Data</button>
      <p>{status}</p>
      <p>{message}</p>
    </div>
  );
}

export default App;
