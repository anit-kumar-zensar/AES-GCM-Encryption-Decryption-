
import React, { useState, useEffect } from "react";
import cryptoService from "../../utils/EncryptDecrpt"; // Import the CryptoService

const Login = () => {
  const [encryptedPassword, setEncryptedPassword] = useState("");
  const [serverResponse, setServerResponse] = useState("");
  const [password, setPassword] = useState("");
  const [serverPublicKey, setServerPublicKey] = useState(null);  // Store server public key

  useEffect(() => {
    // Fetch the server's public key
    fetch("http://localhost:3001/api/get-public-key")
      .then((res) => res.json())
      .then((data) => {
        // Store server public key as PEM string
        setServerPublicKey(data.publicKey);
      })
      .catch((error) => console.error("Error fetching server public key:", error));
  }, []);

  // Convert PEM to Binary DER format (removes headers and footers)
  const pemToBinary = (pem) => {
    const base64 = pem.replace(/-----(BEGIN|END) PUBLIC KEY-----/g, "").replace(/\s/g, "");
    const binaryDer = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
    return binaryDer;
  };

  // Convert PEM to CryptoKey (Web Crypto API)
  // Import public key into the CryptoKey object for ECDH
async function importPublicKey(pemKey) {
    try {
      const binaryDerString = pemToDer(pemKey); // Convert PEM to binary DER
      const publicKey = await window.crypto.subtle.importKey(
        "spki", // We are using SPKI for public key
        binaryDerString, // The binary DER-encoded key
        { name: "ECDH", namedCurve: "P-256" }, // Curve P-256 for ECDH
        false, // The key won't be exported
        ["deriveKey"] // We only want to use it for key derivation
      );
      console.log("Public key imported successfully:", publicKey);
      return publicKey;
    } catch (error) {
      console.error("Error importing public key:", error);
      throw error;
    }
  }
  
  // Helper function to convert PEM to DER
  function pemToDer(pem) {
    const base64 = pem.replace(/-----BEGIN PUBLIC KEY-----/g, "").replace(/-----END PUBLIC KEY-----/g, "").trim();
    const binaryDerString = atob(base64);
    const binaryArray = new Uint8Array(binaryDerString.length);
    for (let i = 0; i < binaryDerString.length; i++) {
      binaryArray[i] = binaryDerString.charCodeAt(i);
    }
    return binaryArray.buffer;
  }
  

  // Encrypt the password and send it to the server
  const handleLogin = async () => {
    console.log(serverPublicKey)
    // if (!serverPublicKey||!window.serverPublicKey) {
    //   console.error("Server public key is not loaded yet.");
    //   return;
    // }
  
    try {
      console.log("Generating client keys...");
      const clientKeys = await cryptoService.generateECDHKeys();
      console.log("Client keys:", clientKeys);
  
      const clientPublicKey = clientKeys.publicKey;
      const clientPrivateKey = clientKeys.privateKey;
  
      console.log("Server Public Key (PEM format):", serverPublicKey);
  
      // Import the server's public key as a CryptoKey object
      const serverCryptoKey = await importPublicKey(serverPublicKey);
      console.log("Imported server CryptoKey:", serverCryptoKey);
  
      // Derive shared secret using client's private key and server's public key
      const sharedSecret = await cryptoService.deriveSharedSecret(
        clientPrivateKey,
        serverCryptoKey
      );
  
      // Derive AES key from the shared secret
      const aesKey = await cryptoService.deriveAESKey(sharedSecret);
  
      // Encrypt the password using the AES key
      const encrypted = await cryptoService.encryptData(aesKey, password);
      setEncryptedPassword(encrypted);
  
      // Log before sending data to the server
      console.log("Sending data to server:", {
        publicKey: clientPublicKey,
        encryptedPassword: encrypted,
      });
  
      // Send the public key and encrypted password to the server
      const response = await fetch("http://localhost:3001/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          publicKey: clientPublicKey,
          encryptedPassword: encrypted,
        }),
      });
  
      const result = await response.json();
      setServerResponse(result.message); // Show server response (success/failure)
    } catch (error) {
      console.error("Error during login:", error);
      setServerResponse("Login failed");
    }
  };
  
  
  return (
    <div>
      <h1>Login</h1>
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Enter password"
      />
      <button onClick={handleLogin}>Login</button>
      <p>{serverResponse}</p>
    </div>
  );
};

export default Login;
