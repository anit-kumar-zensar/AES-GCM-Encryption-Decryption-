import logo from './logo.svg';
import './App.css';

function App() {
  // Generate ECDH Key Pair on the Frontend
async function generateECDHKeyPair() {
  const algorithm = { name: 'ECDH', namedCurve: 'P-256' };
  const keyPair = await window.crypto.subtle.generateKey(
    algorithm,
    true,
    ['deriveKey', 'deriveBits']
  );

  return keyPair;
}

// Derive shared secret using the client's private key and server's public key
async function deriveSharedSecret(clientPrivateKey, serverPublicKey) {
  const sharedSecret = await window.crypto.subtle.deriveBits(
    {
      name: 'ECDH',
      public: serverPublicKey
    },
    clientPrivateKey,
    256 // Shared secret size in bits
  );

  return sharedSecret;
}

// Convert shared secret to AES symmetric key
async function deriveSymmetricKey(sharedSecret) {
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    sharedSecret,
    'AES-GCM',
    true,
    ['encrypt', 'decrypt']
  );

  return keyMaterial;
}

// Encrypt data using AES-GCM
async function encryptText(plainText, symmetricKey) {
  const iv = window.crypto.getRandomValues(new Uint8Array(12)); // Initialization vector
  const encoder = new TextEncoder();
  const data = encoder.encode(plainText);

  const encryptedData = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv,
    },
    symmetricKey,
    data
  );

  return {
    iv: iv,
    encryptedText: new Uint8Array(encryptedData),
  };
}
// Fetch the server's public key from the backend
async function fetchServerPublicKey1() {
  const response = await fetch('http://localhost:5000/api/server-public-key');
  const data = await response.json();
  return data.publicKey; // Return the server's public key
}


// Example function to handle signup or login
async function handleSignupOrLogin1() {
  const clientKeyPair = await generateECDHKeyPair();
  const serverPublicKey = await fetchServerPublicKey(); // Assume this fetches the server's public key

  const sharedSecret = await deriveSharedSecret(clientKeyPair.privateKey, serverPublicKey);
  const symmetricKey = await deriveSymmetricKey(sharedSecret);
  
  const { iv, encryptedText } = await encryptText('mySensitivePassword', symmetricKey);

  // Send the encrypted data (along with IV) to the backend
  await fetch('http://localhost:5000/api/encrypt', {
    method: 'POST',
    body: JSON.stringify({ iv: Array.from(iv), encryptedText: Array.from(encryptedText) }),
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

async function handleSignupOrLogin2() {
  const clientKeyPair = await generateECDHKeyPair();
  const serverPublicKey = await fetchServerPublicKey(); // Fetch the server's public key

  const serverPublicKeyBuffer = new Uint8Array(Buffer.from(serverPublicKey, 'base64'));
  
  const sharedSecret = await deriveSharedSecret(clientKeyPair.privateKey, serverPublicKeyBuffer);
  const symmetricKey = await deriveSymmetricKey(sharedSecret);
  
  const { iv, encryptedText } = await encryptText('mySensitivePassword', symmetricKey);

  // Send the encrypted data (along with IV) to the backend
  await fetch('http://localhost:5000/api/encrypt', {
    method: 'POST',
    body: JSON.stringify({ iv: Array.from(iv), encryptedText: Array.from(encryptedText) }),
    headers: {
      'Content-Type': 'application/json',
    },
  });
}
// Function to convert base64 string to Uint8Array in the browser
function base64ToUint8Array(base64) {
  const binaryString = atob(base64);  // Decode base64 to binary string
  const length = binaryString.length;
  const uint8Array = new Uint8Array(length);

  for (let i = 0; i < length; i++) {
    uint8Array[i] = binaryString.charCodeAt(i);
  }

  return uint8Array;
}

// Fetch the server's public key from the backend
async function fetchServerPublicKey() {
  const response = await fetch('http://localhost:5000/api/server-public-key');
  const data = await response.json();
  return data.publicKey; // Return the server's public key as base64 string
}

// Usage inside your main code
async function handleSignupOrLogin() {
  const clientKeyPair = await generateECDHKeyPair();
  const serverPublicKey = await fetchServerPublicKey(); // Fetch the server's public key

  // Convert base64 server public key to Uint8Array (browser-compatible)
  const serverPublicKeyBuffer = base64ToUint8Array(serverPublicKey);

  const sharedSecret = await deriveSharedSecret(clientKeyPair.privateKey, serverPublicKeyBuffer);
  const symmetricKey = await deriveSymmetricKey(sharedSecret);
  
  const { iv, encryptedText } = await encryptText('mySensitivePassword', symmetricKey);

  // Send the encrypted data (along with IV) to the backend
  await fetch('http://localhost:5000/api/encrypt', {
    method: 'POST',
    body: JSON.stringify({ iv: Array.from(iv), encryptedText: Array.from(encryptedText) }),
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <button
          onClick={()=>handleSignupOrLogin()}
        >
         Sign up
        </button>
      </header>
    </div>
  );
}

export default App;
